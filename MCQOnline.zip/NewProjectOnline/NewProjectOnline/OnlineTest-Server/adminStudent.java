import java.awt.*;
import java.awt.event.*;
import  javax.swing.*;

public class adminStudent extends JFrame implements ActionListener
{	
	Container co;
 
	JLabel l1;
	JButton jbnew, jbmod, jbdel, jbback;
	int w,h;
	int no=0;
	String nm="null";
	String []name;
	
	adminStudent()
	{
		co=getContentPane();
		co.setLayout(null);
		this.no=00;
		this.nm="asfd dffd dfdf";

		w=(int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		h=(int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	
	
		name=nm.split(" ");	
		l1=new JLabel("<html>Student Administration Window </html>");
		l1.setFont(new Font("Arial",Font.PLAIN,40));
		l1.setForeground(new Color(0,0,255));
		l1.setBounds(w/2-300,h/8,700,100);

		jbnew=new JButton("Add new");
		jbnew.setFont(new Font("Copperplate Gothic",Font.PLAIN,18));
		jbnew.setBackground(new Color(94,125,251));
		jbnew.setForeground(new Color(255,255,255));
		jbnew.addActionListener(this);
		jbnew.setBounds(w/2-370,h/2-50,200,50);

		jbmod=new JButton("Modify");
		jbmod.setFont(new Font("Copperplate Gothic",Font.PLAIN,18));
		jbmod.setBackground(new Color(94,125,251));
		jbmod.setForeground(new Color(255,255,255));
		jbmod.addActionListener(this);
		jbmod.setBounds(w/2-100,h/2-50,200,50);
		
		jbdel=new JButton("View");
		jbdel.setFont(new Font("Copperplate Gothic",Font.PLAIN,18));
		jbdel.setBackground(new Color(94,125,251));
		jbdel.setForeground(new Color(255,255,255));
		jbdel.addActionListener(this);
		jbdel.setBounds(w/2+170,h/2-50,200,50);

		jbback=new JButton("Back");
		jbback.setFont(new Font("Copperplate Gothic",Font.PLAIN,18));
		jbback.setBackground(new Color(94,125,251));
		jbback.setForeground(new Color(255,255,255));
		jbback.addActionListener(this);
		jbback.setBounds(w/2-100,h/2+80,200,50);
		
	 
		co.add(l1);
 
		co.add(jbnew);
		co.add(jbmod);
		co.add(jbdel);
		co.add(jbback);
		
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setSize(w,h);
		setUndecorated(true);
		setVisible(true);
	}
	 
	public void actionPerformed(ActionEvent ae)
	{
		 JButton jb=(JButton)ae.getSource();
		 if(jb == jbnew){
			new adminStudent_new();
			setVisible(false);
		}

		else if(jb == jbmod){
			new adminStudent_mod();
			setVisible(false);
		}

		else if(jb == jbdel){
			new adminStudent_del();
			setVisible(false);
		}

		else if(jb == jbback){
			new ServerAdministration();
			setVisible(false);
		}

	}
}