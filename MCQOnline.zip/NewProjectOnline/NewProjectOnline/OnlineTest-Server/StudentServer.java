import java.sql.*;
import java.util.*;
import java.io.*;
class StudentServer 
{
	String driver="com.mysql.jdbc.Driver";
	String url="jdbc:mysql://localhost:3306/onlineexam?useSSL=true";
	String user="root";
	String pass="";
	String sql="";
	
	Connection conn;
	PreparedStatement stat;
	Statement stat1;
	
	ResultSet rs=null;
	
	StudentServer()
	{
		try
		{
			Class.forName(driver);
			conn=DriverManager.getConnection(url,user,pass);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	boolean insertRecord(int rno, String name,String pass,String email,String img)
	{
		
		try
		{
			sql="insert into student(rollno,name,password,email,image) values(?,?,?,?,?) ON DUPLICATE KEY update name=?,password=?,email=?,image=?";	
			stat=conn.prepareStatement(sql);
			stat.setInt(1,rno);
			stat.setString(2,name);
			stat.setString(3,pass);
			stat.setString(4,email);
			
			File file=new File(img);
            FileInputStream fis=new FileInputStream(file);
			stat.setBinaryStream(5,fis,(int)file.length());
			
			
			stat.setString(6,name);
			stat.setString(7,pass);
			stat.setString(8,email);
			fis=new FileInputStream(file);
			stat.setBinaryStream(9,fis,(int)file.length());
			stat.executeUpdate();
			fis.close();
			return true;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return false;
	}
	Stud getStudent(int rollno)
	{
		Stud s=new Stud();
		try
		{
			sql="select name,password,email,image from student where rollno=?";
			stat=conn.prepareStatement(sql);
			stat.setInt(1,rollno);
			
			rs=stat.executeQuery();
			if(rs.next())
			{
				s.nm=rs.getString("name");
				s.pass=rs.getString("password");
				s.email=rs.getString("email");
				
				
				File file=new File("images/"+rollno+".png");
				FileOutputStream fos=new FileOutputStream(file);

				Blob blob=rs.getBlob("image");
				byte b[]=blob.getBytes(1,(int)blob.length());
				fos.write(b);
				fos.close();	
				s.img=""+rollno+".png";
				return s;
			}
			else
				return null;
		}
		catch(Exception e)
		{
			System.out.println(e);
			return s;
		}
		//return null;
	}
	boolean deleteStudent(int rollno)
	{
		try
		{
			sql="delete from student where rollno=?";
			stat=conn.prepareStatement(sql);
			stat.setInt(1,rollno);
			
			stat.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
			return false;
		}
		return true;
	}
	
	String getName(int r)
	{
		try
		{
			
			TimeData td=new TimeData();
			sql="update student set login='"+td.getTime()+"' where rollno=?";
			stat=conn.prepareStatement(sql);
			stat.setInt(1,r);
			
			stat.executeUpdate();
			
			sql="select name from student where rollno=?";
			stat=conn.prepareStatement(sql);
			stat.setInt(1,r);
			
			rs=stat.executeQuery();
			while(rs.next())
				return rs.getString("name");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return "NOT DATA FOUND";
	}
	
	String getPassword(int r)
	{
		try
		{
			sql="select password from student where rollno=?";
			stat=conn.prepareStatement(sql);
			stat.setInt(1,r);
			rs=stat.executeQuery();
			while(rs.next())
				return rs.getString("password");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return "password";
	}
	
	void setMark(int r,int m,String t)
	{
		try
		{
			sql="update student set mark=?,time=?,submit='YES' where rollno=?";
			stat=conn.prepareStatement(sql);
			stat.setInt(1,m);
			stat.setString(2,t);
			stat.setInt(3,r);
			stat.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	void setTime(int r,String t)
	{
		try
		{
			sql="update student set login=? where rollno=?";
			stat=conn.prepareStatement(sql);
			stat.setString(1,t);
			stat.setInt(2,r);
			stat.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	String[][] getSortedData(int sort)
	{
		String s[][]=new String[56][6];
		int i=0,j=0;
		try
		{
		
			if(sort==1)
				sql="select * from student order by rollno asc";
			else
				sql="select * from student order by mark desc,time asc";
			stat1=conn.createStatement();
			rs=stat1.executeQuery(sql);
			while(rs.next())
			{
				for( j=1;j<7;j++)
				{
					s[i][j-1]=rs.getString(j);
				}
				i++;
			}
		}
		catch(Exception e)
		{
			System.out.println(""+e);
		}
		return s;
	}
	
	
	
	public static void main(String args[])
	{
		new StudentServer().insertRecord(18301,"abc cyx djf ","12345","abc@123"," ");
	}
}