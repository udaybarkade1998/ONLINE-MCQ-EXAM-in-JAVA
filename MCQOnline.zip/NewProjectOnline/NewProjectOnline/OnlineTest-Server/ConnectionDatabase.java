import java.sql.*;
class ConnectionDatabase
{
	String driver="com.mysql.jdbc.Driver";
	String url="jdbc:mysql://localhost:3306/onlineexam?useSSL=true";
	String user="root";
	String password="";
	static Connection conn;
	public void setConnection()
	{
		try
		{
			Class.forName(driver);
			conn=DriverManager.getConnection(url,user,password);
			//stat=conn.createStatement();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}