import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

//to store temporary student info
class Stud{
		int no;
		String nm,pass,img,email;
		Stud()
		{
			no =0 ;
			nm = "";
			pass = "";
			img = "";
			email="";
		}
}

public class ServerAdministration extends JFrame implements ActionListener
{	
	Container co;
 
	JLabel l1;
	JButton jbstu, jbque, jbexit,jbstng;
	int w,h;
	int no=0;
	ServerAdministration()
	{
		super("check");
		co=getContentPane();
		co.setLayout(null);
		co.setBackground(Color.white);

		w=Common.width;
		h=Common.height;
	
		l1=new JLabel("<html>Administration Panel </html>");
		l1.setFont(new Font(Common.adminFont,Font.PLAIN,40));
		l1.setForeground(new Color(0,0,255));
		l1.setBounds(w/2-200,h/8,500,100);
		
		ImageIcon stu = new ImageIcon("images\\student.jpg");
		jbstu=new JButton(stu);
		jbstu.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbstu.setBackground(new Color(94,125,251));
		jbstu.setForeground(new Color(255,255,255));
		jbstu.addActionListener(this);
		jbstu.setBounds(w/2-350,h/2,200,200);

		ImageIcon que = new ImageIcon("images\\question.jpg");
		jbque=new JButton(que);
		jbque.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbque.setBackground(new Color(94,125,251));
		jbque.setForeground(new Color(255,255,255));
		jbque.addActionListener(this);
		jbque.setBounds(w/2+150,h/2,200,200);
		
		
		ImageIcon set = new ImageIcon("images\\setting.png");
		jbstng=new JButton(set);
		jbstng.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbstng.setBackground(new Color(94,125,251));
		jbstng.setForeground(new Color(255,255,255));
		jbstng.addActionListener(this);
		jbstng.setBounds(w/2,h/2,200,200);

		jbexit=new JButton("Exit");
		jbexit.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbexit.setBackground(new Color(94,125,251));
		jbexit.setForeground(new Color(255,255,255));
		jbexit.addActionListener(this);
		jbexit.setBounds(w/2-100,h-100,200,50);
	 
		co.add(l1);
 
		co.add(jbstu);
		co.add(jbstng);
		//co.add(jbque);
		co.add(jbexit);
		
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setSize(w,h);
		setUndecorated(true);
		setVisible(true);
		jbque.setVisible(false);
	}
	public void actionPerformed(ActionEvent ae)
	{
		JButton jb=(JButton)ae.getSource();
		
		if( jb == jbstu){
			new adminStudent();
			setVisible(false);
		}
	
		if(jb == jbstng)
		{
			new Settings();
			setVisible(false);
		}
		
		if(jb == jbexit){
			System.exit(0);
		}
	}
	public static void main(String []arga)
	{
		try 
		{
            //here you can put the selected theme class name in JTattoo
            UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
 
        } 
		catch (Exception ex) 
		{
           System.out.println("Error");
        }
		new ServerAdministration();
	}
}
		