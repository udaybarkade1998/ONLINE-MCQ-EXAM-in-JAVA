import java.awt.*;
import java.awt.event.*;
import  javax.swing.*;
import javax.swing.border.*;
import java.io.*;
import javax.swing.event.*;
import java.util.*;

public class adminStudent_del extends JFrame implements ActionListener
{	
	Container co;
 Stud s=null;
	JLabel l1;
	
	JLabel linfo, lno, lnm, lpass, limg,lemail;
	JTextField tno, tnm,tpass,temail;

	
	JButton jbsearch, jbdel, jbcancle, jbclear;

	FileDialog fd;
	
	int w,h;
	
	adminStudent_del()
	{
		co=getContentPane();
		co.setLayout(null);

		w=(int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		h=(int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	
	
		l1=new JLabel("<html>View Student [Administration Window] </html>");
		l1.setFont(new Font(Common.adminFont,Font.PLAIN,30));
		l1.setForeground(new Color(0,0,255));
		l1.setBounds(w/2-300,30,700,100);

		linfo = new JLabel("Student Information ");
		linfo.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		linfo.setForeground(new Color(0,0,255));
		linfo.setBounds(w/2-300,h/3-30,700,35);

		lno = new JLabel("Roll Number : ");
		lno.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		lno.setForeground(new Color(0,0,255));
		lno.setBounds(w/2-300,h/3-100,700,35);
		
		tno=new JTextField();
		tno.setMargin(new Insets(0,3,0,3));
		tno.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		tno.setHorizontalAlignment(JTextField.CENTER);
		tno.setBorder(new LineBorder(new Color(47,24,248),1));
		tno.setBounds(w/2-100,h/3-90,200,30);
		
		jbsearch=new JButton("Search");
		jbsearch.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbsearch.setBackground(new Color(94,125,251));
		jbsearch.setForeground(new Color(255,255,255));
		jbsearch.addActionListener(this);
		jbsearch.setBounds(w/2+150,h/3-90,150,30);


		lnm = new JLabel("Name [ full ] : ");
		lnm.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		lnm.setForeground(new Color(0,0,255));
		lnm.setBounds(w/2-300,h/3,700,100);
		
		tnm=new JTextField();
		tnm.setMargin(new Insets(0,3,0,3));
		tnm.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		tnm.setHorizontalAlignment(JTextField.LEFT);
		tnm.setBorder(new LineBorder(new Color(47,24,248),1));
		tnm.setBounds(w/2-100,h/3+35,400,30);

		limg = new JLabel(new ImageIcon("images\\login.png"));
		limg.setBounds(w-300,h/3,150,150);
		limg.setBorder(new LineBorder(new Color(47,24,248),1));
		
		lemail = new JLabel("Email ID : ");
		lemail.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		lemail.setForeground(new Color(0,0,255));
		lemail.setBounds(w/2-300,h/3+90,700,100);
		
		temail=new JTextField();
		temail.setMargin(new Insets(0,3,0,3));
		temail.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		temail.setHorizontalAlignment(JTextField.LEFT);
		temail.setBorder(new LineBorder(new Color(47,24,248),1));
		temail.setBounds(w/2-100,h/3+90+35,400,30);
		

		lpass = new JLabel("Login Password : ");
		lpass.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		lpass.setForeground(new Color(0,0,255));
		lpass.setBounds(w/2-300,h/3+180,700,100);
		
		tpass=new JTextField();
		tpass.setMargin(new Insets(0,3,0,3));
		tpass.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		tpass.setHorizontalAlignment(JTextField.LEFT);
		tpass.setBorder(new LineBorder(new Color(47,24,248),1));
		tpass.setBounds(w/2-100,h/3+210,350,30);
		
		
		

		jbdel=new JButton("Delete");
		jbdel.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbdel.setBackground(new Color(94,125,251));
		jbdel.setForeground(new Color(255,255,255));
		jbdel.addActionListener(this);
		jbdel.setBounds(w/2-370,h-150,200,50);

		jbcancle=new JButton("Cancle");
		jbcancle.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbcancle.setBackground(new Color(94,125,251));
		jbcancle.setForeground(new Color(255,255,255));
		jbcancle.addActionListener(this);
		jbcancle.setBounds(w/2-100,h-150,200,50);
		
		jbclear=new JButton("Clear");
		jbclear.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbclear.setBackground(new Color(94,125,251));
		jbclear.setForeground(new Color(255,255,255));
		jbclear.addActionListener(this);
		jbclear.setBounds(w/2+170,h-150,200,50);
		
	 
		co.add(l1);
 
		co.add(linfo);

		co.add(lno);
		co.add(lnm);
		co.add(limg);
		co.add(lpass);
		co.add(lemail);
		co.add(temail);

		co.add(tno);
		co.add(tnm);
		co.add(tpass);

		co.add(jbsearch);
		
		co.add(jbdel);
		co.add(jbcancle);
		co.add(jbclear);
		
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setSize(w,h);
		setUndecorated(true);
		setVisible(true);
	}
	 
	//method to delete record from database
		//search record in database
	Stud search(int no){
		s = Common.stuServer.getStudent(no);//get data from database
		//write code 
		// 1. search record in database
		// 2. access recors and store in  this s object
		// 3. return s object if record found else return null

		return s;
	}


	public void actionPerformed(ActionEvent ae)
	{
		JButton jb=(JButton)ae.getSource();	


		if(jb == jbsearch){
			int no = Integer.parseInt(tno.getText());
			Stud s = search(no);
			if(s == null){
				JOptionPane.showMessageDialog(this, "Record Not Found !");
				return;
			}
			s.no=no;
			ImageShape.setSmallImage(no,true);
			tno.setText(""+s.no);
			tnm.setText(s.nm);
			limg.setIcon(new ImageIcon("images\\"+no+".png"));
			tpass.setText(s.pass);
			temail.setText(s.email);
		}
	
		if(jb == jbdel){
		
			int no = 0;
			if(s!=null)
			{
				no = Integer.parseInt(tno.getText());
				
				tno.setText("");
				tnm.setText("");
				limg.setIcon(new ImageIcon("images\\login.png"));
				tpass.setText("");
				temail.setText("");
				if(Common.stuServer.deleteStudent(no))
					JOptionPane.showMessageDialog(this, "Record Modified Successfully !");
				else
					JOptionPane.showMessageDialog(this, "ERROR!");
			}
			else
				JOptionPane.showMessageDialog(this, "DATA NOT FOUND !");
		}

		else if(jb == jbcancle){
			new adminStudent();
			setVisible(false);
		}
		else if(jb == jbclear){
			  tno.setText("");
			  tnm.setText("");
			  limg.setIcon(new ImageIcon("images\\login.png"));
			  tpass.setText("");
			  temail.setText("");
			  temail.setText("");
		}
	}

	public static void main(String []arga)
	{
		new adminStudent_del();
	}
}