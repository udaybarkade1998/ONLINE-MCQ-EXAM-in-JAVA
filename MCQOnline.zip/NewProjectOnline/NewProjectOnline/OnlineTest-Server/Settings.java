import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.io.*;
import javax.swing.event.*;
import java.util.*;

public class Settings extends JFrame implements ActionListener
{	
	Container co;
 	Stud s=null;
	JLabel l1;
	
	JLabel  lno, lnm;
	JTextField tno, tnm;

	
	JButton jbmod,jbback;
	FileDialog fd;
	
	int w,h;
	
	Settings()
	{
		co=getContentPane();
		co.setLayout(null);

		w=(int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		h=(int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	
	
		l1=new JLabel("<html>View Student [Administration Window] </html>");
		l1.setFont(new Font(Common.adminFont,Font.PLAIN,30));
		l1.setForeground(new Color(0,0,255));
		l1.setBounds(w/2-300,30,700,100);

		

		lno = new JLabel("Exam Time(minutes): ");
		lno.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		lno.setForeground(new Color(0,0,255));
		lno.setBounds(w/2-300,h/3-100,700,35);
		


		tno=new JTextField(Common.setServer.getTime());
		tno.setMargin(new Insets(0,3,0,3));
		tno.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		tno.setHorizontalAlignment(JTextField.CENTER);
		tno.setBorder(new LineBorder(new Color(47,24,248),1));
		tno.setBounds(w/2-100,h/3-90,200,30);
		

		lnm = new JLabel("Exam Name  : ");
		lnm.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		lnm.setForeground(new Color(0,0,255));
		lnm.setBounds(w/2-300,h/3,700,100);
		
		tnm=new JTextField(Common.setServer.getName());
		tnm.setMargin(new Insets(0,3,0,3));
		tnm.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		tnm.setHorizontalAlignment(JTextField.LEFT);
		tnm.setBorder(new LineBorder(new Color(47,24,248),1));
		tnm.setBounds(w/2-100,h/3+35,400,30);

	
		jbmod=new JButton("Modify");
		jbmod.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbmod.setBackground(new Color(94,125,251));
		jbmod.setForeground(new Color(255,255,255));
		jbmod.addActionListener(this);
		jbmod.setBounds(w/2-370,h-150,200,50);

		
		
		jbback=new JButton("Back");
		jbback.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbback.setBackground(new Color(94,125,251));
		jbback.setForeground(new Color(255,255,255));
		jbback.addActionListener(this);
		jbback.setBounds(w/2+170,h-150,200,50);
		
	 
		co.add(l1);
 
		

		co.add(lno);
		co.add(lnm);
		
		
		co.add(tno);
		co.add(tnm);

		co.add(jbmod);
		
		co.add(jbback);
		
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setSize(w,h);
		setUndecorated(true);
		setVisible(true);
	}
	 
	//method to delete record from database
		//search record in database




	public void actionPerformed(ActionEvent ae)
	{
		JButton jb=(JButton)ae.getSource();	

		if(jb==jbmod)
		{
			Common.setServer.insertRecord(tnm.getText(),tno.getText());
			JOptionPane.showMessageDialog(this,"Updated Succesfully");
		}

		if(jb == jbback)
		{
			new ServerAdministration();
			setVisible(false);
		}
	}

	public static void main(String []arga)
	{
		new Settings();
	}
}