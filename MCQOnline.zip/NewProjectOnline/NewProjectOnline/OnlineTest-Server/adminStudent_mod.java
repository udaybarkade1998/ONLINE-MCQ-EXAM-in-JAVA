import java.awt.*;
import java.awt.event.*;
import  javax.swing.*;
import javax.swing.border.*;
import java.io.*;
import javax.swing.event.*;
import java.util.*;

//to store temporary student info

public class adminStudent_mod extends JFrame implements ActionListener
{	
	Container co;
 Stud s;
	JLabel l1;
	
	JLabel lno, lnm, lpass, limg,lemail;
	JTextField tno, tnm, timg, tpass,temail;
	JButton jbimg;
	
	JButton jbsearch, jbsave, jbcancle, jbclear;

	FileDialog fd;
	
	int w,h;
	
	adminStudent_mod()
	{
		co=getContentPane();
		co.setLayout(null);

		w=(int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		h=(int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	
	
		l1=new JLabel("<html>Modify Student [Administration Window] </html>");
		l1.setFont(new Font(Common.adminFont,Font.PLAIN,30));
		l1.setForeground(new Color(0,0,255));
		l1.setBounds(w/2-300,30,700,100);


		lno = new JLabel("Roll Number : ");
		lno.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		lno.setForeground(new Color(0,0,255));
		lno.setBounds(w/2-300,h/3-45,300,30);
		
		tno=new JTextField();
		tno.setMargin(new Insets(0,3,0,3));
		tno.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		tno.setHorizontalAlignment(JTextField.CENTER);
		tno.setBorder(new LineBorder(new Color(47,24,248),1));
		tno.setBounds(w/2-100,h/3-45,200,30);
		
		jbsearch=new JButton("Search");
		jbsearch.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbsearch.setBackground(new Color(94,125,251));
		jbsearch.setForeground(new Color(255,255,255));
		jbsearch.addActionListener(this);
		jbsearch.setBounds(w/2+150,h/3-45,150,30);

		lnm = new JLabel("Name [ full ] : ");
		lnm.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		lnm.setForeground(new Color(0,0,255));
		lnm.setBounds(w/2-300,h/3+20,700,30);
		
		tnm=new JTextField();
		tnm.setMargin(new Insets(0,3,0,3));
		tnm.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		tnm.setHorizontalAlignment(JTextField.LEFT);
		tnm.setBorder(new LineBorder(new Color(47,24,248),1));
		tnm.setBounds(w/2-100,h/3+20,400,30);
		
		lemail = new JLabel("Email ID :");
		lemail.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		lemail.setForeground(new Color(0,0,255));
		lemail.setBounds(w/2-300,h/3+90,700,30);
		
		temail=new JTextField();
		temail.setMargin(new Insets(0,3,0,3));
		temail.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		temail.setHorizontalAlignment(JTextField.LEFT);
		temail.setBorder(new LineBorder(new Color(47,24,248),1));
		temail.setBounds(w/2-100,h/3+90,400,30);

		limg = new JLabel("Student image : ");
		limg.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		limg.setForeground(new Color(0,0,255));
		limg.setBounds(w/2-300,h/3+150,700,30);
		
		timg=new JTextField();
		timg.setMargin(new Insets(0,3,0,3));
		timg.setFont(new Font(Common.adminFont,Font.PLAIN,15));
		timg.setHorizontalAlignment(JTextField.LEFT);
		timg.setBorder(new LineBorder(new Color(47,24,248),1));
		timg.setBounds(w/2-100,h/3+150,230,30);
		
		jbimg=new JButton("Select file");
		jbimg.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbimg.setBackground(new Color(94,125,251));
		jbimg.setForeground(new Color(255,255,255));
		jbimg.addActionListener(this);
		jbimg.setBounds(w/2+150,h/3+150,150,30);

		lpass = new JLabel("Login Password : ");
		lpass.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		lpass.setForeground(new Color(0,0,255));
		lpass.setBounds(w/2-300,h/3+230,700,30);

		tpass=new JTextField();
		tpass.setMargin(new Insets(0,3,0,3));
		tpass.setFont(new Font(Common.adminFont,Font.PLAIN,20));
		tpass.setHorizontalAlignment(JTextField.CENTER);
		tpass.setBorder(new LineBorder(new Color(47,24,248),1));
		tpass.setBounds(w/2-100,h/3+230,350,30);

		jbsave=new JButton("Save");
		jbsave.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbsave.setBackground(new Color(94,125,251));
		jbsave.setForeground(new Color(255,255,255));
		jbsave.addActionListener(this);
		jbsave.setBounds(w/2-370,h-150,200,50);

		jbcancle=new JButton("Cancle");
		jbcancle.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbcancle.setBackground(new Color(94,125,251));
		jbcancle.setForeground(new Color(255,255,255));
		jbcancle.addActionListener(this);
		jbcancle.setBounds(w/2-100,h-150,200,50);
		
		jbclear=new JButton("Clear");
		jbclear.setFont(new Font(Common.adminFont,Font.PLAIN,18));
		jbclear.setBackground(new Color(94,125,251));
		jbclear.setForeground(new Color(255,255,255));
		jbclear.addActionListener(this);
		jbclear.setBounds(w/2+170,h-150,200,50);
		
	 
		co.add(l1);
 
		co.add(lno);
		co.add(lnm);
		co.add(limg);
		co.add(lpass);

		co.add(tno);
		co.add(tnm);
		co.add(lemail);
		co.add(temail);
		co.add(timg);
		co.add(tpass);

		co.add(jbsearch);
		co.add(jbimg);

		co.add(jbsave);
		co.add(jbcancle);
		co.add(jbclear);
		
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setSize(w,h);
		setUndecorated(true);
		setVisible(true);
	}

	//search record in database
	Stud search(int no)
	{
		s =Common.stuServer.getStudent(no);
		///write code 
		// 1. search record in database
		// 2. access recors and store in  this s object
		// 3. return s object if record found else return null

		return s;
	}

	public void actionPerformed(ActionEvent ae)
	{
		JButton jb=(JButton)ae.getSource();	

		if(jb == jbsearch){
			try{
			int no = Integer.parseInt(tno.getText());
			Stud s = search(no);
			if(s == null){
				JOptionPane.showMessageDialog(this, "Record Not Found !");
				return;
			}
			s.no=no;
			ImageShape.setSmallImage(no,true);
			tno.setText(""+s.no);
			tnm.setText(s.nm);
			tpass.setText(s.pass);
			temail.setText(s.email);
			
			timg.setText(new File("images//"+s.no+".png").toPath().toAbsolutePath().toString());
			}catch(Exception e){System.out.println(e);}
		}
		if(jb == jbimg){//add student image file
			fd=new FileDialog(this,"Select File",FileDialog.LOAD);
	 		fd.setVisible(true);		
			File f=new File(fd.getDirectory()+fd.getFile());
			if(fd.getFile()!=null)
				timg.setText(fd.getDirectory()+fd.getFile());	
		}		
		if(jb == jbsave){
			Stud s = new Stud();
			s.no = 0;
			s.no = Integer.parseInt(tno.getText());

			s.nm = tnm.getText();
			s.pass = tpass.getText();
			s.img = timg.getText();
			s.email=temail.getText();

			tno.setText("");
			tnm.setText("");
			timg.setText("");
			tpass.setText("");
			temail.setText("");

			if(Common.stuServer.insertRecord(s.no,s.nm,s.pass,s.email,s.img))
				JOptionPane.showMessageDialog(this, "Record Modified Successfully !");
			else
				JOptionPane.showMessageDialog(this, "Record Not Modified Successfully !");
		}

		else if(jb == jbcancle){
			new adminStudent();
			setVisible(false);
		}
		else if(jb == jbclear){
			  tno.setText("");
			  tnm.setText("");
			  timg.setText("");
			  tpass.setText("");
			  temail.setText("");
		}
	}

	public static void main(String []arga)
	{
		new adminStudent_mod();
	}
}