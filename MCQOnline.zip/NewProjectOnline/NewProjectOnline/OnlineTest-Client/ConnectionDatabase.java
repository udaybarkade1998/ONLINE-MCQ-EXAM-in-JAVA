import java.sql.*;
import javax.swing.*;
class ConnectionDatabase
{
	String driver="com.mysql.jdbc.Driver";
	String url="jdbc:mysql://localhost:3306/onlineexam?useSSL=true";
	String user="root";
	String password="";
	static Connection conn;
	boolean connsuccess=false;
	public void setConnection()
	{
		try
		{
			Class.forName(driver);
			
		}
		catch(Exception e){JOptionPane.showMessageDialog(null,"Class Path Missing", "Failure", JOptionPane.ERROR_MESSAGE);
		System.exit(0);
		}
		while(!connsuccess)
		{
			try
			{
				String ip=JOptionPane.showInputDialog("Enter server IP address or server name");
				if(ip.length()!=0)
					url=url.replace("localhost",ip);
				//System.out.println(url);
				conn=DriverManager.getConnection(url,user,password);
				connsuccess=true;
				//stat=conn.createStatement();
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null,"Error:"+e, "Failure", JOptionPane.ERROR_MESSAGE);
				
			}
		}
	}
}