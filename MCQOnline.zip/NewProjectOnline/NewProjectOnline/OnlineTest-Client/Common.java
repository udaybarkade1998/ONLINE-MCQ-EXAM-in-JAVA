import java.awt.Toolkit;
class Common
{
	static String adminFont="Arial";
	static int width=(int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	static int height=(int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	//static StudentServer stuServer=new StudentServer();
	static SettingServer setServer=new SettingServer();
}