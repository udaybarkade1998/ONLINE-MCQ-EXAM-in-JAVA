import java.sql.*;
import java.util.*;
import java.io.*;
class SettingServer 
{
	String driver="com.mysql.jdbc.Driver";
	String url="jdbc:mysql://localhost:3306/onlineexam?useSSL=true";
	String user="root";
	String pass="";
	String sql="";
	
	Connection conn;
	PreparedStatement stat;
	Statement stat1;
	
	ResultSet rs=null;
	
	SettingServer()
	{
		
		try
		{
			Class.forName(driver);
			conn=DriverManager.getConnection(url,user,pass);
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

	boolean insertRecord(String name,String time)
	{
		
		try
		{
			sql="update setting SET test_name=? ,test_time=? WHERE id=?";
			stat=conn.prepareStatement(sql);
			
			stat.setString(1,name);
			stat.setString(2,time);
			stat.setInt(3,1);
			
			System.out.println("OK");
			stat.executeUpdate();
			return true;
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return false;
	}

	
	
	String getName()
	{
		try
		{
			sql="select test_name from setting where id=?";
			stat=conn.prepareStatement(sql);
			stat.setInt(1,1);
			
			rs=stat.executeQuery();
			
			while(rs.next())
				return rs.getString("test_name");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return "NO DATA FOUND";
	}
	
	String getTime()
	{
		try
		{
			sql="select test_time from setting where id=?";
			stat=conn.prepareStatement(sql);
			stat.setInt(1,1);
			
			rs=stat.executeQuery();
			
			while(rs.next())
				return rs.getString("test_time");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return "NO DATA FOUND";
	}
	
	
	
	
	
	public static void main(String args[])
	{
		
	}
}